exports.handler = async (event) => {
    
    console.log('HERE ================ HERE ::: HERE ================ HERE ::: HERE ================ HERE ::: HERE ================ HERE');
    const redis = require('redis');
    const redis_client = redis.createClient({
        host: 'redis.qoauvk.ng.0001.aps1.cache.amazonaws.com',
        port: 6379
    });

    const name = event.pathParameters.for;

    const ret = await redis_client.incr(name); //increment a key dog or cat

    await redis_client.quit();
    
    const response = {
        statusCode: 200,
        body: ret,
    };
    return response;
};
