exports.handler = async (event) => {

    console.log('HERE ================ HERE ::: HERE ================ HERE ::: HERE ================ HERE ::: HERE ================ HERE');
    const redis = require('redis');
    const redis_client = redis.createClient({
        host: 'redis.qoauvk.ng.0001.aps1.cache.amazonaws.com',
        port: 6379
    });

    const dog = await redis_client.get("dog"); //increment a key dog or cat
    const cat = await redis_client.get("cat");

    await redis_client.quit();

    const response = {
        statusCode: 200,
        body: { "dog": dog, "cat": cat },
    };
    return "RESPONSE";
};